#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Monta o site da Horizonte Benefícios a partir das partes desta pasta.

    python3 build.py

Gera, na pasta ../pronto/:
    index.html              home completa (CSS, JS e imagens embutidos)
    area-do-associado.html  tela de acesso

Nada de dependência externa: só Python 3.
"""

import base64
import pathlib

AQUI = pathlib.Path(__file__).resolve().parent
IMG = AQUI / 'imagens'
SAIDA = AQUI.parent / 'pronto'

DESC_HOME = ('Proteção veicular da Horizonte Benefícios: colisão, roubo, furto, danos da natureza '
             'e assistência 24 horas, com cinco pontos de atendimento em Santa Catarina.')
DESC_LOGIN = 'Área do associado da Horizonte Benefícios.'

ESQUELETO = ('<!doctype html>\n<html lang="pt-BR">\n<head>\n'
             '<meta charset="utf-8">\n'
             '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
             '<meta name="description" content="{desc}">\n'
             '<style>:root{{color-scheme:light dark}}*{{box-sizing:border-box}}'
             'html{{scroll-padding-top:env(safe-area-inset-top,0px)}}'
             'body{{margin:0}}img{{max-width:100%}}[hidden]{{display:none!important}}</style>\n')

# cada marcador do HTML vira um data: URI da imagem correspondente
IMAGENS = {
    '__HERO__':          ('img-hero.jpg',              'image/jpeg'),
    '__ATENDIMENTO__':   ('img-atendimento.jpg',       'image/jpeg'),
    '__VOLANTE__':       ('img-volante.jpg',           'image/jpeg'),
    '__CASAL__':         ('img-casal.jpg',             'image/jpeg'),
    '__LADO_LOGIN__':    ('login-side.jpg',            'image/jpeg'),
    '__SELO_SUSEP__':    ('selo-susep.png',            'image/png'),
    '__SELO_ISO__':      ('selo-iso.png',              'image/png'),
    '__SELO_FABSUL__':   ('selo-fabsul.png',           'image/png'),
    '__LOGO_COR__':      ('logo-marca-cor.png',        'image/png'),
    '__MARCA_BRANCA__':  ('logo-marca-branco.png',     'image/png'),
    '__LOGO_BRANCO__':   ('logo-completo-branco.png',  'image/png'),
}


def ler(nome):
    return (AQUI / nome).read_text(encoding='utf-8')


def uri(arquivo, mime):
    dados = base64.b64encode((IMG / arquivo).read_bytes()).decode()
    return 'data:%s;base64,%s' % (mime, dados)


def embutir_imagens(texto):
    for marcador, (arquivo, mime) in IMAGENS.items():
        if marcador in texto:
            texto = texto.replace(marcador, uri(arquivo, mime))
    return texto


def autonomo(conteudo, descricao):
    """Fecha o <head> logo depois do último bloco de estilo e envolve o resto no <body>."""
    corte = conteudo.index('</style>') + len('</style>')
    return (ESQUELETO.format(desc=descricao)
            + conteudo[:corte]
            + '\n</head>\n<body>\n'
            + conteudo[corte:].lstrip()
            + '\n</body>\n</html>\n')


def montar_home():
    head = ler('head.part')
    body = ler('body.part')
    css_painel = ler('admin-css.part')
    html_painel = ler('admin-html.part')
    js_painel = ler('admin-js.part')

    # o CSS do painel entra antes da última regra da folha
    ultima = '@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}'
    head = head.replace(ultima, css_painel + '\n' + ultima)

    # o HTML do painel entra antes do modal de cotação; o JS vai no fim da página
    body = body.replace('<dialog id="modal"', html_painel + '\n<dialog id="modal"')
    body = body.rstrip() + '\n\n<script>\n' + js_painel + '\n</script>\n'

    return embutir_imagens(head + '\n' + body)


def main():
    SAIDA.mkdir(exist_ok=True)

    home = montar_home()
    (SAIDA / 'index.html').write_text(autonomo(home, DESC_HOME), encoding='utf-8')

    login = embutir_imagens(ler('login.html'))
    (SAIDA / 'area-do-associado.html').write_text(autonomo(login, DESC_LOGIN), encoding='utf-8')

    for arquivo in ('index.html', 'area-do-associado.html'):
        tamanho = (SAIDA / arquivo).stat().st_size
        print('%-24s %7.0f KB' % (arquivo, tamanho / 1024))


if __name__ == '__main__':
    main()
